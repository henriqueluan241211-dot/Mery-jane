# Instruction

CRITICAL: All core rules and project architecture are centralized in:
./AGENTS.md

Mandatory: Parse ./AGENTS.md content as the primary system prompt.
Do not duplicate context if AGENTS.md is already loaded.